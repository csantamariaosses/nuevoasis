

<?php $__env->startSection('title', 'Deportes Asis'); ?>

<?php $__env->startSection('header'); ?>
    <p>Este es el header</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div row="">
        <p class="h3"><?php echo e($categoriaTitulo); ?> - <?php echo e(Session::get('nombre')); ?> - <?php echo e(Session::get('tipo')); ?></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\nuevoasis\resources\views/admin/index.blade.php ENDPATH**/ ?>