

<?php $__env->startSection('title', 'Deportes Asis'); ?>

<?php $__env->startSection('header'); ?>
    <p>Este es el header</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
          <p class="h3">Recupera Contraseña...</p>
    </div>
    <div class="row">
         <div class="col-sm-12">
          <?php if(session()->has('flash-message-success')): ?> 
             <div class="alert alert-success">
               <?php echo e(session()->get('flash-message-success')); ?> 
             </div>
          <?php endif; ?> 
          <?php if(session()->has('flash-message-warning')): ?> 
             <div class="alert alert-warning">
               <?php echo e(session()->get('flash-message-warning')); ?> 
             </div>
          <?php endif; ?> 
         </div>
    </div> 
    <hr> 
    <div class="row">
          <div class="row">
            <div class="col-sm-6">
                <div class="well well-sm">

                 <form name="frmAcceso" id="frmAcceso" action="<?php echo e(route('olvidoPasswordEnvioCorreo')); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="accion" id="accion" value="recuperarPasswordPreparaToken">
                     <div class="form-group"> <!-- Correo Usuario -->
                       <label for="emaiResetPass"control-label">Correo electronico</label>
                       <input type="text" class="form-control" id="emailResetPass" name="emailResetPass" placeholder="Correo electronico" required>
                     </div>    
                     <div class="form-group"> <!-- Submit Button -->
                         <button type="submit" class="btn btn-primary" disabled>Enviar</button>
                    </div>   
                 </form>
                 </div>
            </div>
            <div class="col-sm-6">

            </div>
        </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\nuevoasis\resources\views/usuarios/olvidoPassword.blade.php ENDPATH**/ ?>