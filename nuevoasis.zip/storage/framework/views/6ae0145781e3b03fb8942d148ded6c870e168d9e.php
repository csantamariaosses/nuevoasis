

<?php $__env->startSection('title', 'Deportes Asis'); ?>

<?php $__env->startSection('header'); ?>
    <p>Este es el header</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div row="">
        <p class="h3"><?php echo e($categoriaTitulo); ?></p>
    </div>
    <div class="row">
         <div class="col-sm-12">
          <?php if(session()->has('alert-success')): ?> 
             <div class="alert alert-success">
               <?php echo e(session()->get('alert-success')); ?> 
             </div>
          <?php endif; ?> 
           <?php if(session()->has('alert-warning')): ?> 
             <div class="alert alert-warning">
               <?php echo e(session()->get('alert-warning')); ?> 
             </div>
          <?php endif; ?> 
          <?php if(session()->has('flash-message-success')): ?> 
             <div class="alert alert-success">
               <?php echo e(session()->get('flash-message-success')); ?> 
             </div>
          <?php endif; ?> 
          <?php if(session()->has('flash-message-warning')): ?> 
             <div class="alert alert-warning">
               <?php echo e(session()->get('flash-message-warning')); ?> 
             </div>
          <?php endif; ?> 
          
         </div>
    </div>  
    <div class="row">
            <div class="col-sm-6">
                <div class="well well-sm">
                 Acceder
                 <form name="frmAcceso" id="frmAcceso" action="<?php echo e(route('micuenta-acceso')); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="accion" id="accion" value="acceso">
                     <div class="form-group"> <!-- Correo Usuario -->
                       <label for="usuario" class="control-label">Correo electronico</label>
                       <input type="text" class="form-control" id="emailAcc" name="emailAcc" placeholder="Usuario o correo electronico" required>
                     </div>    
                     <div class="form-group"> <!-- Pass -->
                       <label for="passwordAcc" class="control-label">Contrase&nacute;a</label>        <a href="<?php echo e(route('olvidoPassword')); ?>"><span align="right">Olvido de contrase&nacute;a?</span></a>
                       <input type="password" class="form-control" id="passwordAcc" name="passwordAcc" placeholder="Contrase&nacute;a" required>
                     </div>    
                     <div class="form-group"> <!-- Submit Button -->
                         <button type="submit" class="btn btn-primary">Acceder</button>
                    </div>   
                 </form>
                 </div>
            </div>
            <div class="col-sm-6">
                 <div class="well well-sm">
                 Registrarse 
                 <form name="frmRegistro" id="frmRegistro" action="<?php echo e(route('micuenta-registro')); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="accion" id="accion" value="registro">
                       <div class="form-group"> <!-- Nombre -->
                       <label for="nombre" class="control-label">Nombre</label>
                       <input type="text" class="form-control" id="nombreRegis" name="nombreRegis" placeholder="Nombre" required>
                     </div>                         
                     <div class="form-group"> <!-- Correo Usuario -->
                       <label for="usuario" class="control-label">Correo electronico</label>
                       <input type="text" class="form-control" id="emailRegis" name="emailRegis" placeholder="Usuario o correo electronicor" required>
                     </div>    
                     <div class="form-group"> <!-- Pass -->
                       <label for="passwordRegis" class="control-label">Contrase&nacute;a</label>
                       <input type="password" class="form-control" id="passwordRegis" name="passwordRegis" placeholder="Contrase&nacute;a" required>
                     </div>  
                     <div class="form-group"> <!-- Fono Contacto -->
                       <label for="fonoContacto" class="control-label">Fono Contacto</label>
                       <input type="text" class="form-control" id="fonoContacto" name="fonoContacto" placeholder="Fono contacto" required>
                     </div>  

                   
                      <div class="form-group">
                         <div class="g-recaptcha"  data-sitekey="<?php echo e(env('GOOGLE_RECAPTCHA_KEY','xxx')); ?>">
                         </div>
                      </div>
  
                     <div class="form-group"> <!-- Submit Button -->
                         <button type="submit" class="btn btn-primary" onClick="validar();">Registrarse</button>
                    </div>   
                 </form>
                 <!--
                 <?php //if( strlen( $msg ) >0 ) { ?>
                    <div class="alert alert-warning alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                         <?php // echo $msg; ?>
                    </div>
                 
                 <?php //} ?>
               -->
            </div>
        </div>
    </div>
  </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\nuevoasis\resources\views/micuenta.blade.php ENDPATH**/ ?>