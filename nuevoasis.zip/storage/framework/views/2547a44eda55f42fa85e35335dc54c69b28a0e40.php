<?php $__env->startSection('content'); ?>

  <div class="container">
     <div class="row" style="margin-top: 20px;">
         <p class="h3"><?php echo e($categoriaTitulo); ?></p>
     </div>
     <div class="row">
          <?php if( count( $productos) >0 ): ?>        
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4">
                <div class="thumbnail">
                      <p class="cuadro-imagen centrado">                        
                        <img src="<?php echo e(asset('storage').'/imagenes'); ?>/<?php echo e($dato->imagen); ?>" alt="..." width="200" class="zoom">
                        
                      </p>
                        <div class="caption centrado">
                            <h5><?php echo e(\Illuminate\Support\Str::limit($dato->nombre, 10, $end='...')); ?></h3>                       
                            <p>
                                <form name="frm" action="" method="POST">
                                    <?php echo e(csrf_field()); ?>  
                                  <input type="hidden" name="hdAccion" value="agregarAlCarrito">
                                  <input type="hidden" name="hdId" value="<?php echo e($dato->id); ?>">
                                  <input type="hidden" name="hdIdProducto" value="<?php echo e($dato->idProducto); ?>">
                                  <input type="hidden" name="hdNombre" value="<?php echo e($dato->nombre); ?>">
                                                                          
                                  <a href="#" class="btn btn-default" role="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($dato->id); ?>"><i class="fa fa-eye" aria-hidden="true"></i>  Ver...</a>

                                     
                                  <!--
                                  <?php if( $dato->stock == 1 ): ?>
                                    <a href="#" class="btn btn-default">Agregar al carrito</a>
                                  <?php else: ?>
                                    <a href="#" class="btn btn-default" disabled>Agregar al carrito</a>
                                  <?php endif; ?>                      
                                  -->
                                </form>
                                <?php if( strcmp(session()->get('tipo'),'admin' ) == 0 ): ?>
                                  <button type="button" class="btn btn-default" onClick="location.href='<?php echo e(action('AdminController@adminProductosEditar',[$dato->id])); ?>'">Ir a Config...</button>
                                <?php endif; ?>
                          </p>
                        </div> <!-- caption -->
                </div> <!-- thum -->    
              </div>  <!-- col-sm-4 -->

              <!--- Aqui el modal -->
             <!-- Modal -->
              <div class="modal fade" id="exampleModal<?php echo e($dato->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?php echo e($dato->nombre); ?></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                      <p class="cuadro-imagen text-center">                        
                        <img src="<?php echo e(asset('storage').'/imagenes'); ?>/<?php echo e($dato->imagen); ?>" alt="..." width="400" class="zoom">
                      </p>
                      <hr>
                      <h5><?php echo e($dato->nombre); ?></h3>  
                      <!-- <h5><?php echo e($dato->imagen); ?></h3>   -->
                      <p>
                        <?php 
                          if( stripos( $dato->descripcion, '<br>') > 0) {
                              //echo "Contiene brs:<br>";
                              echo $dato->descripcion . "<br>";
                              /*
                              $tokens = strtok($dato->descripcion, "<br>");
                             while ($tokens !== false) {
                              echo $tokens . "-";
                              $tokens = strtok("<br>");
                             }  
                              */              
                          } 
                        ?>
                      </p> 
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                  </div>
                </div>
              </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          <?php else: ?>
            <br><h4>No Existen Productos En Su Busqueda</h4>        
          <?php endif; ?>

   </div>   <!-- row -->
</div>  <!-- container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\nuevoasis\resources\views/home.blade.php ENDPATH**/ ?>